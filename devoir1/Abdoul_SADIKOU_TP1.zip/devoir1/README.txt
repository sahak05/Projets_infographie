Abdoul SADIKOU
20158628
------------------------

Explications des deformations dans la partie II

Ma premiere deformation :
Est celui sur l'armadillo qui se déforme selon les normales avec le FFT,
les couleurs changent avec un effet de feu selon le temps en utilisant une fonction de bruit. Donc en utilisant du code pris 
sur internet a l'adresse: https://greentec.github.io/shadertoy-fire-shader-en/#other-effects et passe dans le fragment shader.
Le premier controleur controle cette deformation.

Ma deuxieme deformation:  
Honnetement pas grand chose de faite. J'ai essaye de faire un changement de couleur suivant le temps qui est controle par le temps 
et la fonction de bruit et du cote du vertex shader jai creer une deformation qui agit uniquement sur la tete est les pieds de 
l'armadillio.


 Ps: j'ai laisse l'armadillio avec la couleur de l'effet en feu et chaque controleur montrera le changement de couleur
   dans le sens chaque deformation mis par les controleurs a sa propre couleur 

